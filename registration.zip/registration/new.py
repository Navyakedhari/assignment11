from flask import Flask, render_template, request

web = Flask(__name__)

@web.route('/')
@web.route('/registration')
def home():
    return render_template('registration.html')

@web.route("/confirmation", methods=['POST', 'GET'])
def register():
    if request.method == "POST":
        n = request.form.get('name')
        e = request.form.get('email_id')
        p = request.form.get('phone')
        c = request.form.get('city')
        s = request.form.get('state')
        a = request.form.get('pincode')
        return render_template(
            'confirm.html',
            name=n,
            email_id=e,
            phone=p,
            city=c,
            state=s,
            pincode=a
        )
    return None


if __name__ == "__main__":
    web.run(debug=True)
